<?php

/** @var \Illuminate\Database\Eloquent\Factory $factory */

use App\ModelBlog;
use Faker\Generator as Faker;

$factory->define(ModelBlog::class, function (Faker $faker) {
    return [
        //
    ];
});
