<?php return array (
  'asesores-component' => 'App\\Http\\Livewire\\AsesoresComponent',
  'mis-pqrs' => 'App\\Http\\Livewire\\MisPqrs',
  'nuevo-pqrs' => 'App\\Http\\Livewire\\NuevoPqrs',
  'pqrs-aceptados' => 'App\\Http\\Livewire\\PqrsAceptados',
  'pqrs-asesor' => 'App\\Http\\Livewire\\PqrsAsesor',
  'pqrs-pendientes' => 'App\\Http\\Livewire\\PqrsPendientes',
  'register' => 'App\\Http\\Livewire\\Register',
  'todos-clientes' => 'App\\Http\\Livewire\\TodosClientes',
  'todos-pqrs' => 'App\\Http\\Livewire\\TodosPqrs',
);