@extends('layouts.admin_app')

@section('contenido')

@livewire('asesores-component')

@endsection