@extends('layouts.admin_app')

@section('contenido')

    @livewire('pqrs-aceptados')

@endsection