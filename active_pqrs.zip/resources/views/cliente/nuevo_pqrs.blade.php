@extends('layouts.admin_app')

@section('contenido')

    @livewire('nuevo-pqrs')

@endsection