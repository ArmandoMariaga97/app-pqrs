<?php $__env->startSection('content'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('register')->html();
} elseif ($_instance->childHasBeenRendered('qAX5vSU')) {
    $componentId = $_instance->getRenderedChildComponentId('qAX5vSU');
    $componentTag = $_instance->getRenderedChildComponentTagName('qAX5vSU');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('qAX5vSU');
} else {
    $response = \Livewire\Livewire::mount('register');
    $html = $response->html();
    $_instance->logRenderedChild('qAX5vSU', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\j_r\resources\views/auth/register.blade.php ENDPATH**/ ?>