

<?php $__env->startSection('contenido'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('asesores-component')->html();
} elseif ($_instance->childHasBeenRendered('OgZH5bx')) {
    $componentId = $_instance->getRenderedChildComponentId('OgZH5bx');
    $componentTag = $_instance->getRenderedChildComponentTagName('OgZH5bx');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('OgZH5bx');
} else {
    $response = \Livewire\Livewire::mount('asesores-component');
    $html = $response->html();
    $_instance->logRenderedChild('OgZH5bx', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\j_r\resources\views/admin/asesores/index.blade.php ENDPATH**/ ?>