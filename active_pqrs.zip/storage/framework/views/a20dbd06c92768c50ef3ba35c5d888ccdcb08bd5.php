<?php $__env->startSection('contenido'); ?>
<br><br>
<h1 align="center">¿Qué quieres hacer hoy?</h1>
<br><br>
<div class="row">
    <div class="col-lg-4 col-12">
      <div class="card pull-up">
        <a href="<?php echo e(route('encuestas')); ?>">
            <div class="card-content">
            <div class="card-body">
                <div class="media d-flex">
                <div class="media-body text-left">
                    <h6 class="text-muted">Gestionar</h6>
                    <h3>ENCUESTAS</h3>
                </div>
                <div class="align-self-center">
                    <i class="icon-picture primary font-large-2 float-right"></i>
                </div>
                </div>
            </div>
            </div>
        </a>
      </div>
    </div>
    <div class="col-lg-4 col-12">
      <div class="card pull-up">
        <a href="#">
            <div class="card-content">
            <div class="card-body">
                <div class="media d-flex">
                <div class="media-body text-left">
                    <h6 class="text-muted">Gestionar</h6>
                    <h3> COLABRADORES</h3>
                </div>
                <div class="align-self-center">
                    <i class="icon-badge danger font-large-2 float-right"></i>
                </div>
                </div>
            </div>
            </div>
        </a>
      </div>
    </div>
    <div class="col-lg-4 col-12">
      <div class="card pull-up">
        <a href="#">
            <div class="card-content">
            <div class="card-body">
                <div class="media d-flex">
                <div class="media-body text-left">
                    <h6 class="text-muted">Gestionar</h6>
                    <h3>ESTADISTICAS</h3>
                </div>
                <div class="align-self-center">
                    <i class="icon-book-open success font-large-2 float-right"></i>
                </div>
                </div>
            </div>
            </div>
        </a>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-encuestas\resources\views/admin/index.blade.php ENDPATH**/ ?>