

<?php $__env->startSection('contenido'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('todos-pqrs')->html();
} elseif ($_instance->childHasBeenRendered('Ap8Q8P8')) {
    $componentId = $_instance->getRenderedChildComponentId('Ap8Q8P8');
    $componentTag = $_instance->getRenderedChildComponentTagName('Ap8Q8P8');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Ap8Q8P8');
} else {
    $response = \Livewire\Livewire::mount('todos-pqrs');
    $html = $response->html();
    $_instance->logRenderedChild('Ap8Q8P8', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\j_r\resources\views/admin/pqrs/index.blade.php ENDPATH**/ ?>