
            <div class="col-md-12">
              <div class="card ">
                <div class="card-header">
                    <h4 align="center" class="card-title text-green form-create">EDITAR VENDEDOR</h4>
                    <hr>
                </div>
                <div class="card-content collapse show">
                  <div class="card-body">
                    <form class="form-horizontal error" >
                      <div class="row justify-content-center">
                        <div class="col-lg-12 col-md-12">

                          <div class="form-group mt-2">
                            <div class="controls">
                              <input type="text" wire:model.defer="nombre" class="form-control"  placeholder="nombre">
                              <?php $__errorArgs = ['nombre'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                          <div class="form-group mt-2">
                            <div class="controls">
                              <input type="text" wire:model.defer="correo" class="form-control"  placeholder="correo">
                              <?php $__errorArgs = ['correo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                          <div class="form-group mt-2">
                            <div class="controls">
                              <input type="text" wire:model.defer="documento" class="form-control"  placeholder="documento">
                              <?php $__errorArgs = ['documento'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                          <div class="form-group mt-2">
                            <div class="controls">
                              <input type="text" wire:model.defer="direccion" class="form-control"  placeholder="direccion">
                              <?php $__errorArgs = ['direccion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>

                          <div class="form-group mt-2">
                            <button type="button" wire:click="limpiarcampos" class="btn btn-danger text-white">Cancelar</button>
                            <button type="button" wire:click="update" class="btn btn-primary text-white">Atualizar</button>
                          </div>
                          
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
<?php /**PATH C:\laragon\www\j_r\resources\views/livewire/asesores/form_edit.blade.php ENDPATH**/ ?>