

<?php $__env->startSection('contenido'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('vendedore-component')->html();
} elseif ($_instance->childHasBeenRendered('g2HQQ6V')) {
    $componentId = $_instance->getRenderedChildComponentId('g2HQQ6V');
    $componentTag = $_instance->getRenderedChildComponentTagName('g2HQQ6V');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('g2HQQ6V');
} else {
    $response = \Livewire\Livewire::mount('vendedore-component');
    $html = $response->html();
    $_instance->logRenderedChild('g2HQQ6V', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armandomariaga\resources\views/admin/vendedores/index.blade.php ENDPATH**/ ?>