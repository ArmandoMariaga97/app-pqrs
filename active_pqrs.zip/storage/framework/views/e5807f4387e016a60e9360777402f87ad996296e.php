<div>

  <?php $__env->startPush('archivos'); ?>
  <script type="text/javascript" src="/assets/jquery.min.js"></script>
	<link rel="stylesheet" type="text/css" href="/assets/toastr/toastr.css">
  <script type="text/javascript" src="/assets/toastr/toastr.js"></script>
  <?php $__env->stopPush(); ?>

  <div class="row" id="default">
                      
          <?php if(session()->has('delete-success')): ?>
              <script  type="text/javascript">
                    toastr.error('Entrada al BLOG ELIMINADA correctamente.', 'Bien hecho!!');
              </script>
          <?php endif; ?>
          <?php if(session()->has('update-success')): ?>
              <script  type="text/javascript">
                    $(function(){
                      $('#form-edit-closed').click();
                    });
                    toastr.success('Entrada al BLOG ACTUALIZADA correctamente.', 'Bien hecho!!');
              </script>
          <?php endif; ?>
          <?php if(session()->has('store-success')): ?>
              <script  type="text/javascript">
                    $(function(){
                      $('#form-create-closed').click();
                    });
                    toastr.success('Entrada al BLOG AGREGADA correctamente.', 'Bien hecho!!');
              </script>
          <?php endif; ?>

          <?php echo $__env->make("livewire.blog.forms_blog", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h2 class="card-title">Entradas al BLOG</h2>
                <!-- <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a> -->
                <!-- <div class="heading-elements">
                </div> -->
              </div>
              <div class="card-content collapse show">
                <div class="table-responsive">
                  <table class="table mb-0">
                    <thead>
                      <tr>
                        <th style="width:30%;">Título</th>
                        <th style="width:60%;">Contenido</th>
                        <th style="width:10%;" colspan="2">&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__empty_1 = true; $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                            <tr>
                                <td  align="center">
                                  <?php echo e(Str::limit($blog->titulo , 80)); ?> 
                                  <br>
                                  <img style="max-height:100px;" src="<?php echo e(asset('uploads/blog/'.$blog->img )); ?>"></img>
                                  <br>
                                  <?php echo e($blog->created_at); ?>

                                </td>
                                <td><?php echo e(Str::limit($blog->contenido , 500)); ?></td>
                                <td  align="center">
                                    <li style="list-style:none;">
                                        <ul>
                                            <buttom class="btn btn-warning" title="Ver Blog"><i class="icon-eye"></i></buttom>
                                        </ul>
                                        <ul>
                                            <a href="#default" wire:click="edit(<?php echo e($blog->id); ?>)" class="btn btn-success" title="Editar Blog"><i class="icon-note"></i></a>
                                        </ul>
                                        <ul>
                                            <buttom data-toggle="modal" data-target="#delete-modal-<?php echo e($blog->id); ?>" class="btn btn-danger" title="Eliminar Blog"><i class="icon-close"></i></buttom>
                                        </ul>
                                    </li>
                                </td>
                            </tr>
                            <?php echo $__env->make("livewire.blog.delete_blog", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                            <td align="center" colspan="4">No has agregado contenido a tu BLOG</td>
                        <?php endif; ?>
                    </tbody>
                  </table>
                  <?php echo e($blogs->links()); ?>

                </div>
              </div>
            </div>
          </div>
        </div>
</div>
<?php /**PATH C:\laragon\www\web-admin\resources\views/livewire/blog/blog-component.blade.php ENDPATH**/ ?>