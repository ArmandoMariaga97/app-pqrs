

<?php $__env->startSection('contenido'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pqrs-aceptados')->html();
} elseif ($_instance->childHasBeenRendered('0IPGinn')) {
    $componentId = $_instance->getRenderedChildComponentId('0IPGinn');
    $componentTag = $_instance->getRenderedChildComponentTagName('0IPGinn');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('0IPGinn');
} else {
    $response = \Livewire\Livewire::mount('pqrs-aceptados');
    $html = $response->html();
    $_instance->logRenderedChild('0IPGinn', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\j_r\resources\views/asesor/pqrs_aceptados.blade.php ENDPATH**/ ?>