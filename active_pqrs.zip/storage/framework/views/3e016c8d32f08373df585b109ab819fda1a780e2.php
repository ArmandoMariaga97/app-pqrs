<!DOCTYPE html>
<html lang="en">
<head>
</head>
<body>
    
    <div style="background: #16AEF8; width: 100%; border-radius: 15px;">
        <h1 align="center" style="padding: 30px; color:white;">Respuesta PQRS</h1>
    </div>
    <div style="background: gray; width: 100%; border-radius: 15px;">
        <div style="padding:20px; color: white;">
            <h2 align="center">Se brindó respuesta al Radicado # <?php echo e($info['radicado']); ?></h2>
            <hr>
            <p>Puede ver su respuesta ingresando por el siguiente link <a href="http://127.0.0.1:8000/cliente/mis-pqrs">Mis PQRS</a></p>
        </div>
    </div>

</body>
</html><?php /**PATH C:\laragon\www\j_r\resources\views/mail/respuesta_pqrs.blade.php ENDPATH**/ ?>