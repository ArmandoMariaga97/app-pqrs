

<?php $__env->startSection('contenido'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('blog-component')->html();
} elseif ($_instance->childHasBeenRendered('BA2FW2D')) {
    $componentId = $_instance->getRenderedChildComponentId('BA2FW2D');
    $componentTag = $_instance->getRenderedChildComponentTagName('BA2FW2D');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('BA2FW2D');
} else {
    $response = \Livewire\Livewire::mount('blog-component');
    $html = $response->html();
    $_instance->logRenderedChild('BA2FW2D', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\Prueba-livewire\resources\views/admin/blog/index.blade.php ENDPATH**/ ?>