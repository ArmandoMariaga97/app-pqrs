<div>

        <?php echo $__env->make('livewire.vendedores.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row">
            
            <?php echo $__env->make("livewire.vendedores.$form", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="col-8">
                <div class="card">
                    <div class="card-header">
                        <h2 align="center" class="card-title">VENDEDORES REGISTRADOS</h2>
                    </div>
                    <div class="card-content collapse show">
                        <div class="m-1">
                            <p>Filtrar por: 
                            <select wire:model="type_filter"> 
                                <option value="name">nombre</option>
                                <option value="documento">documento</option>
                                <option value="email">correo</option>
                                <option value="direccion">dirección</option>
                            </select>
                            <input type="text" wire:model="search"></p>
                        </div>
                        <div class="table-responsive">
                        <table class="table mb-0">
                            <thead>
                            <tr>
                                <th style="width:20%;">Nombre</th>
                                <th style="width:20%;">Documento</th>
                                <th style="width:20%;">Correo</th>
                                <th style="width:20%;">Dirección</th>
                                <th style="width:20%;">&nbsp;</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $vendedores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vendedor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($vendedor->name); ?></td>
                                        <?php if($vendedor->documento == null): ?>
                                            <td style="color:red;">Sin información</td>
                                        <?php else: ?>
                                            <td><?php echo e($vendedor->documento); ?></td>
                                        <?php endif; ?>
                                        <td><?php echo e($vendedor->email); ?></td>
                                        <?php if($vendedor->direccion == null): ?>
                                            <td style="color:red;">Sin información</td>
                                        <?php else: ?>
                                            <td><?php echo e($vendedor->direccion); ?></td>
                                        <?php endif; ?>
                                        <td  align="center">
                                            
                                            <button wire:click="edit(<?php echo e($vendedor->id); ?>)" class="btn btn-success" title="Editar vendedor"><i class="icon-note"></i></button>
                                                
                                            <buttom data-toggle="modal" data-target="#delete-modal-<?php echo e($vendedor->id); ?>" class="btn btn-danger" title="Eliminar vendedor"><i class="icon-close"></i></buttom>
                                            
                                        </td>
                                    </tr>

                                    <?php echo $__env->make("livewire.vendedores.delete", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <td align="center" colspan="5">Sin resultados</td>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        </div>
                        <?php echo e($vendedores->links()); ?>

                    </div>
                </div>
            </div>
        </div>

</div>
<?php /**PATH C:\laragon\www\j_r\resources\views/livewire/vendedores/vendedore-component.blade.php ENDPATH**/ ?>