
<div class="modal fade text-left" id="ver-mas-<?php echo e($pqrs->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel9"
    aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div style="border: solid 1px blue; border-radius:5px;" class="modal-content">
        <div style="background:blue; border-radius:5px 5px 0 0;" class="modal-header">
          <label class="modal-title text-white text-text-bold-600" > </label>
        </div>
        <div class="modal-body">

        <section class="card">
            <div id="invoice-template" class="card-body">
                <!-- Invoice Company Details -->
                <div id="invoice-company-details" class="row">
                <div class="col-md-6 col-sm-12 text-center text-md-left">
                    <div class="media">
                    <img src="/img/icono.png" alt="company logo" class="">
                    <div class="media-body">
                        <ul class="ml-2 px-0 list-unstyled">
                            <li class="text-bold-800"><b>Active PQRS</b></li>
                            <li>J&R Technology</li>
                            <li>Emprendimiento dígital</li>
                        </ul>
                    </div>
                    </div>
                </div>
                <div class="col-md-6 col-sm-12 text-center text-md-right">
                    <h2> radicado: <b>#<?php echo e($pqrs->radicado); ?></b></h2>
                    <p><b>Tipo de PQRS:</b> <?php echo e($pqrs->tipoRadicado->t_pqr); ?></p>
                    <p class="pb-3"><b>Fecha solicitud:</b> <?php echo e($pqrs->created_at); ?></p>
                    <?php if($pqrs->estado == 1): ?>
                        <span class="badge badge-warning"> Pendiente por aceptación</span>
                    <?php endif; ?>

                    <?php if($pqrs->estado == 2): ?>
                        <span class="badge badge-primary"> Aceptado por asesor</span>
                    <?php endif; ?>

                    <?php if($pqrs->estado == 3): ?>
                        <span class="badge badge-success"> Finalizado se brindo una respuesta</span>
                    <?php endif; ?>
                </div>
                </div>
                <hr>

                <div id="invoice-customer-details" class="row pt-2">
                    <div class="col-sm-12 text-center text-md-left">
                        <p class="text-muted"><b>Datos solicitante PQRS</b></p>
                    </div>
                    <div class="col-md-6 col-sm-12 text-center text-md-left">
                        <ul class="px-0 list-unstyled">
                            <li class="text-bold-800"><b>Nombres:</b> <?php echo e($pqrs->clienteCreador->name); ?></li>
                            <li><b>Correo:</b> <?php echo e($pqrs->clienteCreador->email); ?></li>
                            <li><b>Celular:</b> <?php echo e($pqrs->clienteCreador->celular); ?></li>
                            <li><b>Ciudad:</b> <?php echo e($pqrs->clienteCreador->ciudad); ?></li>
                            <li><b>dirección:</b> <?php echo e($pqrs->clienteCreador->direccion); ?></li>
                        </ul>
                    </div>
                    <div class="col-md-6 col-sm-12 text-center text-md-left">
                        <ul class="px-0 list-unstyled">
                            <p><b>Archivo Anexo Solicitud:</b> 
                                <?php if($pqrs->archivo_solicitud == 'No se cargó ningun archivo'): ?>
                                    No se cargó ningun archivo
                                <?php else: ?>
                                    <a href="/uploads/archivos/<?php echo e($pqrs->archivo_solicitud); ?>"  target="_blank">Ver archivo anexo</a>
                                <?php endif; ?>
                            </p>                        
                        </ul>
                    </div>
                </div>

                <!-- Invoice Footer -->
                <div id="invoice-footer">
                    <div class="row">
                        <div class="col-md-12 col-sm-12">
                            <h4><b>Descripión solicitud PQRS</b></h4>
                            <p><?php echo e($pqrs->descripcion_solicitud); ?></p>
                        </div>

                    </div>
                </div>
                
                <hr>

                <div id="invoice-customer-details" class="row pt-2">
                    <div class="col-sm-12 text-center text-md-left">
                        <p class="text-muted"><b>Datos Asesor PQRS</b></p>
                    </div>
                    <?php if($pqrs->asesorPqrs): ?>
                        <div class="col-md-6 col-sm-12 text-center text-md-left">
                            <ul class="px-0 list-unstyled">
                                <li class="text-bold-800"><b>Nombres:</b> <?php echo e($pqrs->asesorPqrs->name); ?></li>
                            </ul>
                        </div>
                        <div class="col-md-6 col-sm-12 text-center text-md-left">
                            <ul class="px-0 list-unstyled">
                                <p><b>Archivo Anexo Respuesta:</b> 
                                    <?php if($pqrs->archivo_respuesta == null): ?>
                                        No se cargó ningun archivo
                                    <?php else: ?>
                                        <a href="/uploads/archivos/<?php echo e($pqrs->archivo_respuesta); ?>"  target="_blank">Ver archivo anexo</a>
                                    <?php endif; ?>
                                </p>                        
                            </ul>
                        </div>

                        <div class="col-md-6 col-sm-12 text-center text-md-left">
                            <ul class="px-0 list-unstyled">
                                <h4><b>Descripión respuesta PQRS</b></h4>
                                <p><?php echo e($pqrs->descripcion_respuesta); ?></p>
                            </ul>
                        </div>
                        
                    <?php else: ?>
                        <div class="col-md-6 col-sm-12 text-center text-md-left">
                            <ul class="px-0 list-unstyled">
                                <li class="text-bold-800"><p>No se ha asignado ningún asesor a este radicado.</p></li>
                            </ul>
                        </div>
                    <?php endif; ?>
                </div>

            </div>
            </section>

        </div>
        <div class="modal-footer">
           <button type="button" class="btn btn-outline-danger" data-dismiss="modal">Cerrar</button>
        </div>  

    </div>
  </div>
</div>

<?php /**PATH C:\laragon\www\j_r\resources\views/livewire/cliente/detalle_pqrs.blade.php ENDPATH**/ ?>