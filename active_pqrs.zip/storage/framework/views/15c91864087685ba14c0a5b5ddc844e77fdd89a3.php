<?php if(session()->has('register_success')): ?>
      <script  type="text/javascript">
            toastr.success('Asesor agregado con exito.', 'Bien hecho!!');
      </script>
<?php endif; ?>

<?php if(session()->has('update-success')): ?>
      <script  type="text/javascript">
            toastr.success('Asesor actualizado con exito.', 'Bien hecho!!');
      </script>
<?php endif; ?>

<?php if(session()->has('delete-success')): ?>
      <script  type="text/javascript">
            toastr.error('Asesor eliminado con exito.', 'Bien hecho!!');
      </script>
<?php endif; ?><?php /**PATH C:\laragon\www\j_r\resources\views/livewire/asesores/alerts.blade.php ENDPATH**/ ?>