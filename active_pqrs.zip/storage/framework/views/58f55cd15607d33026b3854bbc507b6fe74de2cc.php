

<?php $__env->startSection('contenido'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('clientes-component')->html();
} elseif ($_instance->childHasBeenRendered('Uxhkw5l')) {
    $componentId = $_instance->getRenderedChildComponentId('Uxhkw5l');
    $componentTag = $_instance->getRenderedChildComponentTagName('Uxhkw5l');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Uxhkw5l');
} else {
    $response = \Livewire\Livewire::mount('clientes-component');
    $html = $response->html();
    $_instance->logRenderedChild('Uxhkw5l', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.vendedor_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armandomariaga\resources\views/vendedor/clientes/index.blade.php ENDPATH**/ ?>