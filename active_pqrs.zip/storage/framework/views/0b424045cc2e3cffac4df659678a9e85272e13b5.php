

<?php $__env->startSection('contenido'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pqrs-pendientes')->html();
} elseif ($_instance->childHasBeenRendered('Pifitb5')) {
    $componentId = $_instance->getRenderedChildComponentId('Pifitb5');
    $componentTag = $_instance->getRenderedChildComponentTagName('Pifitb5');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Pifitb5');
} else {
    $response = \Livewire\Livewire::mount('pqrs-pendientes');
    $html = $response->html();
    $_instance->logRenderedChild('Pifitb5', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\j_r\resources\views/asesor/pqrs_pendientes.blade.php ENDPATH**/ ?>