

<?php $__env->startSection('contenido'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('mis-pqrs')->html();
} elseif ($_instance->childHasBeenRendered('ojVA4Cc')) {
    $componentId = $_instance->getRenderedChildComponentId('ojVA4Cc');
    $componentTag = $_instance->getRenderedChildComponentTagName('ojVA4Cc');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('ojVA4Cc');
} else {
    $response = \Livewire\Livewire::mount('mis-pqrs');
    $html = $response->html();
    $_instance->logRenderedChild('ojVA4Cc', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\j_r\resources\views/cliente/mis_pqrs.blade.php ENDPATH**/ ?>