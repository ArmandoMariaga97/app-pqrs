<template x-if="edit_encuesta">
        <div>
            <div align="right" class="mb-2">
                <button x-on:click="edit_encuesta = false" style="margin-right:20px;" type="button" class="btn btn-warning round btn-glow px-2">
                        Regresar
                </button>
            </div>
            <h1><?php echo e($encuesta_edit['titulo']); ?></h1>
        </div>
</template><?php /**PATH C:\laragon\www\app-encuestas\resources\views/livewire/encuestas/edit.blade.php ENDPATH**/ ?>