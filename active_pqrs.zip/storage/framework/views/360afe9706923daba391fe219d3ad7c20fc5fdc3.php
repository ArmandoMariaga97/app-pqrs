

<?php $__env->startSection('contenido'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('todos-clientes')->html();
} elseif ($_instance->childHasBeenRendered('60wFakB')) {
    $componentId = $_instance->getRenderedChildComponentId('60wFakB');
    $componentTag = $_instance->getRenderedChildComponentTagName('60wFakB');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('60wFakB');
} else {
    $response = \Livewire\Livewire::mount('todos-clientes');
    $html = $response->html();
    $_instance->logRenderedChild('60wFakB', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\j_r\resources\views/admin/clientes/index.blade.php ENDPATH**/ ?>