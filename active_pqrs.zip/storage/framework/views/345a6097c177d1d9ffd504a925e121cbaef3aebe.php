<div>

  <div x-show="!open_form">
    <div align="right" class="mb-2">
        <button x-on:click="open_form = true" style="margin-right:20px;" type="button" class="btn btn-success round btn-glow px-2">
              Agregar
        </button>
    </div>
  </div>

  <template x-if="open_form">
    <div align="right" class="mb-2">
        <button  x-on:click="open_form = false, $wire.limpiarcampos()" style="margin-right:20px;" type="button" class="btn btn-danger round btn-glow px-2">
                Cancelar
        </button>
    </div>
</template>

<template x-if="open_form">
  <section class="input-validation">
    <div class="row">
      <div class="col-md-12">
        <div class="card ">
          <div class="card-header">
            <h4 align="center" class="card-title text-green form-create">REGISTRAR NUEVA ENCUESTA</h4>
            <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
            <div class="heading-elements">
              <ul class="list-inline mb-0">
                </ul>
              </div>
              <hr>
                </div>
                <div class="card-content collapse show">
                  <div class="card-body">
                    <form class="form-horizontal error" novalidate="">
                      <div class="row justify-content-center">
                        <div class="col-lg-12 col-md-12">
                          <div class="form-group mt-2">
                            <div class="controls">
                              <input type="text" x-model="titulo" class="form-control"  placeholder="Título de la encuesta">
                              <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                          <div class="form-group mt-2">
                            <div class="controls">
                              <textarea x-model="descripcion" class="form-control" cols="30" rows="10" placeholder="descripción de la encuesta"></textarea>
                              <?php $__errorArgs = ['descripcion'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                            </div>
                          </div>
                          <div class="form-group mt-2">
                            <button type="button" @click="$wire.addencuesta()" class="btn btn-success text-white">Agregar</button>
                          </div>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
              </div>
            </div>
          </div>
    </section>
</template>

</div><?php /**PATH C:\laragon\www\app-encuestas\resources\views/livewire/encuestas/form.blade.php ENDPATH**/ ?>