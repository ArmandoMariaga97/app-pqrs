<div>
    <h1>hola mundo</h1>
</div>
<?php /**PATH C:\laragon\www\armandomariaga\resources\views/livewire/clientes.blade.php ENDPATH**/ ?>