

<?php $__env->startSection('contenido'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('pqrs-asesor')->html();
} elseif ($_instance->childHasBeenRendered('LfsqZpA')) {
    $componentId = $_instance->getRenderedChildComponentId('LfsqZpA');
    $componentTag = $_instance->getRenderedChildComponentTagName('LfsqZpA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LfsqZpA');
} else {
    $response = \Livewire\Livewire::mount('pqrs-asesor');
    $html = $response->html();
    $_instance->logRenderedChild('LfsqZpA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\j_r\resources\views/asesor/mis_pqrs.blade.php ENDPATH**/ ?>