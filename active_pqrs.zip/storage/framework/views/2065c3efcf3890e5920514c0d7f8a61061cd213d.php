<div>
<div class="row" id="default">
            <div align="right" style="width:300px; margin:20px;" class="col-md-12 col-12">
                <button class="btn btn-danger round btn-glow px-2" type="button" data-toggle="modal" data-target="#inlineForm" aria-haspopup="true" aria-expanded="false">Agregar</button>
            </div>
          <div class="col-12">
                <?php $__env->startPush('modal-create'); ?>
                    <?php echo $__env->make('livewire.create_blog', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                <?php $__env->stopPush(); ?>
            <div class="card">
              <div class="card-header">
                <h2 class="card-title">Entradas al BLOG</h2>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
                <div class="heading-elements">
                  <!-- <ul class="list-inline mb-0">
                    <li><a data-action="collapse"><i class="ft-minus"></i></a></li>
                    <li><a data-action="reload"><i class="ft-rotate-cw"></i></a></li>
                    <li><a data-action="expand"><i class="ft-maximize"></i></a></li>
                    <li><a data-action="close"><i class="ft-x"></i></a></li>
                  </ul> -->
                </div>
              </div>
              <div class="card-content collapse show">
                <div class="table-responsive">
                  <table class="table mb-0">
                    <thead>
                      <tr>
                        <th style="width:30%;">Título</th>
                        <th style="width:60%;">Contenido</th>
                        <th style="width:10%;" colspan="2">&nbsp;</th>
                      </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($blog->titulo); ?></td>
                                <td><?php echo e($blog->contenido); ?></td>
                                <td  align="center">
                                    <li style="list-style:none;">
                                        <ul>
                                            <buttom class="btn btn-warning" title="Ver Blog"><i class="icon-eye"></i></buttom>
                                        </ul>
                                        <ul>
                                            <buttom class="btn btn-success" title="Editar Blog"><i class="icon-note"></i></buttom>
                                        </ul>
                                        <ul>
                                            <buttom wire:click="destroy(<?php echo e($blog->id); ?>)" class="btn btn-danger" title="Eliminar Blog"><i class="icon-close"></i></buttom>

                                        </ul>
                                    </li>
                                </td>
                            </tr>
                            <?php $__env->startPush('modals-edit'); ?>
                            <?php $__env->stopPush(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                  </table>
                  <?php echo e($blogs->links()); ?>

                </div>
              </div>
            </div>
          </div>
        </div>
</div>
<?php /**PATH C:\laragon\www\Prueba-livewire\resources\views/livewire/blog-component.blade.php ENDPATH**/ ?>