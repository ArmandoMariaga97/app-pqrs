
<div wire:ignore class="modal fade text-left" id="edit-modal-<?php echo e($blog->id); ?>" tabindex="-1" role="dialog" aria-labelledby="myModalLabel9"
                          aria-hidden="true">
  <div class="modal-dialog modal-lg" role="document">
    <div class="modal-content">
      <div class="modal-header">
        <label class="modal-title text-text-bold-600" id="myModalLabel33">Editar entrada al BLOG</label>
      </div>
        <form action="#">
          <div class="modal-body">
            <label>Título:</label>
            <div class="form-group">
              <input type="text" wire:model="titulo" placeholder="Escribra su titulo" class="form-control">
              <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <label>Contenido: </label>
            <div class="form-group">
              <textarea type="text" wire:model="contenido" placeholder="Escriba su contenido" class="form-control" cols="30" rows="10"></textarea>
              <?php $__errorArgs = ['contenido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <label>Imagen: </label> <br>
            <span>Formatos admitidos JPEG, JPG, PNG, peso max 2mb</span>
            <div class="form-group">
              <input id="archivo" type="file" wire:model="img" placeholder="Seleccione una imágen" class="form-control">
              <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <div>
              <span>Imágen actual</span>
              <img style="max-height:100px;" src="<?php echo e(asset('uploads/blog/'.$blog->img )); ?>"></img>
            </div>
          </div>
          <div class="modal-footer">
            <button type="button" id="form-edit-closed" class="btn btn-default" data-dismiss="modal">Cerrar</button>
            <buttom wire:click="update"  type="reset" class="btn btn-primary btn-lg">Actualizar</buttom>
          </div>
        </form>
    </div>
  </div>
</div>



<?php /**PATH C:\laragon\www\web-admin\resources\views/livewire/blog/edit_blog.blade.php ENDPATH**/ ?>