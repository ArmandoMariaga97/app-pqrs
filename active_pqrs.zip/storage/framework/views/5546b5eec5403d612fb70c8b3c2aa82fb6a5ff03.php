<div>

    <div class="row">


        <div class="col-12">
            <div class="card">
                <div class="card-header">
                    <h2 align="center" class="card-title">MIS PQRS <span style="color:green;">( #<?php echo e($mis_pqrs->count()); ?> )</span></h2>
                </div>
                <hr>
                <div class="card-content collapse show">
                    <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                        <tr>
                            <th style="width:10%;"># Radicado</th>
                            <th style="width:20%;">Tipo PQRS</th>
                            <th style="width:20%;">Asesor</th>
                            <th style="width:20%;">Estado</th>
                            <th style="width:20%;">Fecha Radicado</th>
                            <th style="width:10%;">&nbsp;</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $mis_pqrs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $pqrs): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td># <span style="color:green;"><?php echo e($pqrs->radicado); ?></span></td>
                                    
                                    <td><?php echo e($pqrs->tipoRadicado->t_pqr); ?></td>

                                    <?php if($pqrs->asesor == null): ?>
                                    <td>Sin asignar</td>
                                    <?php else: ?>
                                    <td><?php echo e($pqrs->asesorPqrs->name); ?></td>
                                    <?php endif; ?>

                                    <?php if($pqrs->estado == 1): ?>
                                        <td> <span style="width:100%;" class="badge badge-warning"> Pendiente por aceptación</span></td>
                                    <?php endif; ?>

                                    <?php if($pqrs->estado == 2): ?>
                                        <td> <span style="width:100%;" class="badge badge-primary"> Aceptado por asesor</span></td>
                                    <?php endif; ?>

                                    <?php if($pqrs->estado == 3): ?>
                                        <td> <span style="width:100%;" class="badge badge-success"> Finalizado se brindo una respuesta</span></td>
                                    <?php endif; ?>

                                    <td> <?php echo e($pqrs->created_at); ?> </td>
                                    <td>
                                        <div class="row">
                                            <div class="col-md-6">
                                                <buttom data-toggle="modal" data-target="#ver-mas-<?php echo e($pqrs->id); ?>" class="btn btn-warning" title="Ver más"><i class="icon-eye"></i></buttom>
                                            </div>
                                        </div>                
                                    </td>
                                </tr>

                                <?php echo $__env->make("livewire.cliente.detalle_pqrs", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <td align="center" colspan="5">No has generado PQRS</td>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

</div>
<?php /**PATH C:\laragon\www\j_r\resources\views/livewire/cliente/mis-pqrs.blade.php ENDPATH**/ ?>