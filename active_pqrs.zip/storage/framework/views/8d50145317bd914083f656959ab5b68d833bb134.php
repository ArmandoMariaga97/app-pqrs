

<?php $__env->startSection('contenido'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('galeria-component')->html();
} elseif ($_instance->childHasBeenRendered('jGWP1SA')) {
    $componentId = $_instance->getRenderedChildComponentId('jGWP1SA');
    $componentTag = $_instance->getRenderedChildComponentTagName('jGWP1SA');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('jGWP1SA');
} else {
    $response = \Livewire\Livewire::mount('galeria-component');
    $html = $response->html();
    $_instance->logRenderedChild('jGWP1SA', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web-admin\resources\views/admin/galeria/index.blade.php ENDPATH**/ ?>