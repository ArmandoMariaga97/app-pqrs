<?php if(session()->has('delete-img-success')): ?>
    <script  type="text/javascript">
          toastr.error('Imagen ELIMINADA de la galeria con exito.', 'Bien hecho!!');
    </script>
    <?php echo e(session('delte-img-success')); ?>

<?php endif; ?>
<?php if(session()->has('update-success')): ?>
    <script  type="text/javascript">
          $(function(){
            $('#form-edit-closed').click();
          });
          toastr.success('Entrada al BLOG ACTUALIZADA correctamente.', 'Bien hecho!!');
    </script>
<?php endif; ?>
<?php if(session()->has('photos-success')): ?>
    <script  type="text/javascript">
          $(function(){
            $('#form-create-closed').click();
          });
          toastr.success('Imágenes agregadas correctamente.', 'Bien hecho!!');
    </script>
<?php endif; ?><?php /**PATH C:\laragon\www\web-admin\resources\views/livewire/galeria/alerts.blade.php ENDPATH**/ ?>