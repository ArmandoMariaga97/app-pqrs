<div>

        <?php echo $__env->make('livewire.clientes.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row">
            
            <?php echo $__env->make("livewire.clientes.$form", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

            <div class="col-8">
                <div class="card">
                    <div class="card-header">
                        <h2 align="center" class="card-title">CLIENTES REGISTRADOS</h2>
                    </div>
                    <div class="card-content collapse show">
                        <div class="table-responsive">
                        <table class="table mb-0">
                            <thead>
                            <tr>
                                <th style="width:20%;">Nombre</th>
                                <th style="width:20%;">Documento</th>
                                <th style="width:20%;">Correo</th>
                                <th style="width:20%;">Dirección</th>
                                <th style="width:20%;">&nbsp;</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cliente): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($cliente->nombre); ?></td>
                                        <?php if($cliente->documento == null): ?>
                                            <td style="color:red;">Sin información</td>
                                        <?php else: ?>
                                            <td><?php echo e($cliente->documento); ?></td>
                                        <?php endif; ?>
                                        <td><?php echo e($cliente->correo); ?></td>
                                        <?php if($cliente->direccion == null): ?>
                                            <td style="color:red;">Sin información</td>
                                        <?php else: ?>
                                            <td><?php echo e($cliente->direccion); ?></td>
                                        <?php endif; ?>
                                        <td  align="center">
                                            
                                            <button wire:click="edit(<?php echo e($cliente->id); ?>)" class="btn btn-success" title="Editar cliente"><i class="icon-note"></i></button>
                                                
                                            <buttom data-toggle="modal" data-target="#delete-modal-<?php echo e($cliente->id); ?>" class="btn btn-danger" title="Eliminar cliente"><i class="icon-close"></i></buttom>
                                            
                                        </td>
                                    </tr>

                                    <?php echo $__env->make("livewire.clientes.delete", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <td align="center" colspan="5">Sin resultados</td>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        </div>
                        <?php echo e($clientes->links()); ?>

                    </div>
                </div>
            </div>
        </div>

</div>
<?php /**PATH C:\laragon\www\armandomariaga\resources\views/livewire/clientes/clientes-component.blade.php ENDPATH**/ ?>