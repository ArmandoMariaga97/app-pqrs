<div>
    <h1>Hola mundo</h1>
</div>
<?php /**PATH C:\laragon\www\web-admin\resources\views/livewire/galeria-component.blade.php ENDPATH**/ ?>