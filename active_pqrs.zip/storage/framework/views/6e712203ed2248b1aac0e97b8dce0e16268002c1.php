          <div class="col-12">
            <div class="card">
              <div class="card-header">
                <h2 class="card-title">Agregar entrada al BLOG</h2>
                <a class="heading-elements-toggle"><i class="la la-ellipsis-v font-medium-3"></i></a>
              </div>
              <div class="card-content collapse show">
                <form action="#">
                  <div class="modal-body">
                    <label>Título: </label>
                    <div class="form-group">
                      <input type="text" wire:model="titulo" placeholder="Escribra su titulo" class="form-control">
                      <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <label>Contenido: </label>
                    <div class="form-group">
                      <textarea type="text" wire:model="contenido" placeholder="Escriba su contenido" class="form-control" cols="30" rows="10"></textarea>
                      <?php $__errorArgs = ['contenido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <label>Imagen: </label> <br>
                    <span>Formatos admitidos JPEG, JPG, PNG, peso max 2mb</span>
                    <div class="form-group">
                      <input id="<?php echo e(rand()); ?>" type="file" wire:model="img" placeholder="Seleccione una imágen" class="form-control">
                      <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                  <div class="modal-footer">
                    <buttom wire:click="store" class="btn btn-outline-primary btn-lg">Guardar</buttom>
                  </div>
                </form>
              </div>
            </div>
          </div>
<?php /**PATH C:\laragon\www\Prueba-livewire\resources\views/livewire/blog/create_blog.blade.php ENDPATH**/ ?>