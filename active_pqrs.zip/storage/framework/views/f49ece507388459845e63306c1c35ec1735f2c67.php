

<?php if(session()->has('add-encuesta-success')): ?>
      <script  type="text/javascript">
            toastr.success('Encuesta agregada con exito.', 'Bien hecho!!');
            $(function(){
                  $('.form-closed').show();
                  $('.form-open').hide();
            });
      </script>
<?php endif; ?>

<?php if(session()->has('encuesta-delete')): ?>
      <script  type="text/javascript">
            toastr.error('Encuesta eliminada con exito', 'Bien hecho!!');
            $(function(){
                  $('.form-closed').show();
                  $('.form-open').hide();
            });
      </script>
<?php endif; ?>

<?php if(session()->has('encuesta-updated')): ?>
      <script  type="text/javascript">
            toastr.error('Encuesta eliminada con exito', 'Bien hecho!!');
      </script>
<?php endif; ?>
<?php /**PATH C:\laragon\www\app-encuestas\resources\views/livewire/encuestas/alerts.blade.php ENDPATH**/ ?>