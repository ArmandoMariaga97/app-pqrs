

<?php $__env->startSection('contenido'); ?>

    <?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('nuevo-pqrs')->html();
} elseif ($_instance->childHasBeenRendered('Hn3wtAG')) {
    $componentId = $_instance->getRenderedChildComponentId('Hn3wtAG');
    $componentTag = $_instance->getRenderedChildComponentTagName('Hn3wtAG');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('Hn3wtAG');
} else {
    $response = \Livewire\Livewire::mount('nuevo-pqrs');
    $html = $response->html();
    $_instance->logRenderedChild('Hn3wtAG', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\j_r\resources\views/cliente/nuevo_pqrs.blade.php ENDPATH**/ ?>