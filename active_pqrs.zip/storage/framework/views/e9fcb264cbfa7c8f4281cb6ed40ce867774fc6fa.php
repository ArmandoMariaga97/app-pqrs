

<?php $__env->startSection('contenido'); ?>
<br><br>
<div class="row justify-content-center">
    <div class="col-lg-4 col-12">
      <div class="card pull-up">
        <a href="<?php echo e(route('pqrs_pendientes')); ?>">
            <div class="card-content">
            <div class="card-body">
                <div class="media d-flex">
                <div class="media-body text-left">
                    <h6 class="text-muted">Gestionar</h6>
                    <h3>PQRS Pendientes</h3>
                </div>
                <div class="align-self-center">
                    <i class="icon-list primary font-large-2 float-right"></i>
                </div>
                </div>
            </div>
            </div>
        </a>
      </div>
    </div>
    <div class="col-lg-4 col-12">
      <div class="card pull-up">
        <a href="<?php echo e(route('pqrs_aceptados')); ?>">
            <div class="card-content">
            <div class="card-body">
                <div class="media d-flex">
                <div class="media-body text-left">
                    <h6 class="text-muted">Gestionar</h6>
                    <h3>PQRS Aceptados</h3>
                </div>
                <div class="align-self-center">
                    <i class="icon-book-open primary font-large-2 float-right"></i>
                </div>
                </div>
            </div>
            </div>
        </a>
      </div>
    </div>
    <div class="col-lg-4 col-12">
      <div class="card pull-up">
        <a href="<?php echo e(route('pqrs_asesor')); ?>">
            <div class="card-content">
            <div class="card-body">
                <div class="media d-flex">
                <div class="media-body text-left">
                    <h6 class="text-muted">Gestionar</h6>
                    <h3> PQRS Procesados</h3>
                </div>
                <div class="align-self-center">
                    <i class="icon-check danger font-large-2 float-right"></i>
                </div>
                </div>
            </div>
            </div>
        </a>
      </div>
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\j_r\resources\views/asesor/index.blade.php ENDPATH**/ ?>