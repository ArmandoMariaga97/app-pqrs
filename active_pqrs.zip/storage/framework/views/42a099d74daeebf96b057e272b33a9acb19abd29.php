<div x-data="
    { open_form: <?php if ((object) ('open_form') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('open_form'->value()); ?>')<?php echo e('open_form'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('open_form'); ?>') <?php endif; ?>.defer,
      form_edit: <?php if ((object) ('form_edit') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('form_edit'->value()); ?>')<?php echo e('form_edit'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('form_edit'); ?>') <?php endif; ?>.defer,

      name: <?php if ((object) ('name') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('name'->value()); ?>')<?php echo e('name'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('name'); ?>') <?php endif; ?>.defer,
      documento: <?php if ((object) ('documento') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('documento'->value()); ?>')<?php echo e('documento'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('documento'); ?>') <?php endif; ?>.defer,
      email: <?php if ((object) ('email') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('email'->value()); ?>')<?php echo e('email'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('email'); ?>') <?php endif; ?>.defer,
      celular: <?php if ((object) ('celular') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('celular'->value()); ?>')<?php echo e('celular'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('celular'); ?>') <?php endif; ?>.defer,
      ciudad: <?php if ((object) ('ciudad') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('ciudad'->value()); ?>')<?php echo e('ciudad'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('ciudad'); ?>') <?php endif; ?>.defer,
      direccion: <?php if ((object) ('direccion') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('direccion'->value()); ?>')<?php echo e('direccion'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('direccion'); ?>') <?php endif; ?>.defer,
      id_asesor: <?php if ((object) ('id_asesor') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('id_asesor'->value()); ?>')<?php echo e('id_asesor'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('id_asesor'); ?>') <?php endif; ?>.defer,

    }">

        <?php echo $__env->make('livewire.asesores.alerts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row">

            <div x-show="!open_form" class="col-md-12 mb-1">
                <div class="float-md-right">
                    <button x-on:click="open_form = true" class="btn btn-success round btn-glow px-2" type="button" >Agregar Asesor</button>
                </div>
            </div>
            
            <template x-if="open_form">
                <?php echo $__env->make("livewire.asesores.forms", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </template>

            <div class="col-12">
                <div class="card">
                    <div class="card-header">
                        <h2 align="center" class="card-title">ASESORES REGISTRADOS</h2>
                    </div>
                    <hr>
                    <div class="card-content collapse show">
                        <div class="row justify-content-center">
                            <div class="col-md-12 row justify-content-center mb-1">
                                <div class="col-md-6">
                                    <input type="text" class="form-control" wire:model="buscar" placeholder="Buscar...">
                                </div>
                                <div class="col-md-3">
                                    <select  class="form-control" wire:model="orderBy">
                                        <option value="documento">Ordenar por documento</option>
                                        <option value="name">Ordenar por Nombres</option>
                                        <option value="email">Ordenar por Correo</option>
                                        <option value="celular">Ordenar por Celular</option>
                                        <option value="direccion">Ordenar por dirección</option>
                                    </select>
                                </div>
                                <div class="col-md-3">
                                    <select  class="form-control" wire:model="paginate">
                                        <option value="5">Mostrar primeros 5</option>
                                        <option value="10">Mostrar primeros 10</option>
                                        <option value="20">Mostrar primeros 20</option>
                                        <option value="50">Mostrar primeros 50</option>
                                        <option value="1000">Mostrar todos</option>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="table-responsive">
                        <table class="table mb-0">
                            <thead>
                            <tr>
                                <th style="width:5%;">#</th>
                                <th style="width:15%;">Documento</th>
                                <th style="width:20%;">Nombres</th>
                                <th style="width:15%;">Correo</th>
                                <th style="width:15%;">Celular</th>
                                <th style="width:15%;">Dirección</th>
                                <th style="width:15%;">&nbsp;</th>
                            </tr>
                            </thead>
                            <tbody>
                                <?php $__empty_1 = true; $__currentLoopData = $asesores; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $asesor): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                    <tr>
                                        <td><?php echo e($cont); ?>.</td>
                                        <td><?php echo e($asesor->documento); ?></td>
                                        <td><?php echo e($asesor->name); ?></td>
                                        <td><?php echo e($asesor->email); ?></td>
                                        <td><?php echo e($asesor->celular); ?></td>
                                        <td><?php echo e($asesor->direccion); ?></td>
                                        <td>
                                            <div class="row">
                                                <div class="col-md-6">
                                                    <button x-on:click="open_form = true, $wire.edit(<?php echo e($asesor->id); ?>)" class="btn btn-success ir-arriba" title="Editar asesor"><i class="icon-note"></i></button>
                                                </div>
                                                <div class="col-md-6">
                                                    <buttom data-toggle="modal" data-target="#delete-modal-<?php echo e($asesor->id); ?>" class="btn btn-danger" title="Eliminar asesor"><i class="icon-close"></i></buttom>
                                                </div>
                                            </div>                
                                        </td>
                                    </tr>
                                    <p style="display:none;"><?php echo e($cont++); ?></p>

                                    <?php echo $__env->make("livewire.asesores.delete", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                    <td align="center" colspan="7">Sin resultados</td>
                                <?php endif; ?>
                            </tbody>
                        </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

</div>
<?php /**PATH C:\laragon\www\j_r\resources\views/livewire/asesores/asesores-component.blade.php ENDPATH**/ ?>