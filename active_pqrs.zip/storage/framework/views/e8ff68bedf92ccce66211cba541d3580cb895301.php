<div x-data="{
    id_encuesta: <?php if ((object) ('id_encuesta') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('id_encuesta'->value()); ?>')<?php echo e('id_encuesta'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('id_encuesta'); ?>') <?php endif; ?>.defer, 
    encuesta_edit: <?php if ((object) ('encuesta_edit') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('encuesta_edit'->value()); ?>')<?php echo e('encuesta_edit'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('encuesta_edit'); ?>') <?php endif; ?>.defer, 
    open_form: <?php if ((object) ('open_form') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('open_form'->value()); ?>')<?php echo e('open_form'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('open_form'); ?>') <?php endif; ?>.defer, 
    titulo: <?php if ((object) ('titulo') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('titulo'->value()); ?>')<?php echo e('titulo'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('titulo'); ?>') <?php endif; ?>.defer, 
    descripcion: <?php if ((object) ('descripcion') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('descripcion'->value()); ?>')<?php echo e('descripcion'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('descripcion'); ?>') <?php endif; ?>.defer,
    edit_encuesta: <?php if ((object) ('edit_encuesta') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('edit_encuesta'->value()); ?>')<?php echo e('edit_encuesta'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('edit_encuesta'); ?>') <?php endif; ?>.defer
    }">

    <?php echo $__env->make("livewire.encuestas.alerts", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <div x-show="!edit_encuesta">

        <?php echo $__env->make("livewire.encuestas.form", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <div class="row">
            <div class="col-12">
                <div class="card">
                <div class="card-header">
                    <h2 align="center" class="card-title">ENCUESTAS REGISTRADAS</h2>
                </div>
                <div class="card-content collapse show">
                    <div class="table-responsive">
                    <table class="table mb-0">
                        <thead>
                        <tr>
                            <th style="width:25%;">Título</th>
                            <th style="width:50%;">Descripción</th>
                            <th style="width:15%;">Estado</th>
                            <th style="width:10%;" colspan="2">&nbsp;</th>
                        </tr>
                        </thead>
                        <tbody>
                            <?php $__empty_1 = true; $__currentLoopData = $encuestas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $encuesta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                <tr>
                                    <td  align="center">
                                    <span style="color:green; font-size:10px;">Creada:&nbsp;<?php echo e($encuesta->created_at); ?></span>
                                    <br>
                                    <?php echo e(Str::limit($encuesta->titulo , 80)); ?> 
                                    </td>
                                    <td><?php echo e(Str::limit($encuesta->descripcion , 500)); ?></td>
                                    <?php if($encuesta->activo == 0): ?>
                                    <td><a style="width:100px;" class="btn btn-warning text-white">Inactiva</a></td>
                                    <?php else: ?>
                                    <td><a style="width:100px;" class="btn btn-success text-white">Activa</a></td>
                                    <?php endif; ?>
                                    <td  align="center">
                                        <li style="list-style:none; color:white;">
                                            <ul>
                                                <buttom class="btn btn-warning" title="Ver Encuesta"><i class="icon-eye"></i></buttom>
                                            </ul>
                                            <ul>
                                                <button x-on:click="edit_encuesta = true, $wire.edit(<?php echo e($encuesta->id); ?>)" class="btn btn-success" title="Editar Encuesta"><i class="icon-note"></i></button>
                                            </ul>
                                            <ul>
                                                <buttom data-toggle="modal" data-target="#delete-modal-<?php echo e($encuesta->id); ?>" class="btn btn-danger" title="Eliminar Encuesta"><i class="icon-close"></i></buttom>
                                            </ul>
                                        </li>
                                    </td>
                                </tr>

                                <?php echo $__env->make("livewire.encuestas.delete", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                <td align="center" colspan="5">No has agregado ENCUESTAS</td>
                            <?php endif; ?>
                        </tbody>
                    </table>
                    </div>
                </div>
                </div>
            </div>
        </div>
    </div>

    <?php echo $__env->make('livewire.encuestas.edit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php /**PATH C:\laragon\www\app-encuestas\resources\views/livewire/encuestas/encuestas-component.blade.php ENDPATH**/ ?>