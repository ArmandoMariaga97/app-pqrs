

<?php $__env->startSection('contenido'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('encuestas-component')->html();
} elseif ($_instance->childHasBeenRendered('6MWUkMz')) {
    $componentId = $_instance->getRenderedChildComponentId('6MWUkMz');
    $componentTag = $_instance->getRenderedChildComponentTagName('6MWUkMz');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('6MWUkMz');
} else {
    $response = \Livewire\Livewire::mount('encuestas-component');
    $html = $response->html();
    $_instance->logRenderedChild('6MWUkMz', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\app-encuestas\resources\views/admin/encuestas/index.blade.php ENDPATH**/ ?>