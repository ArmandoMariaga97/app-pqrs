

<?php $__env->startSection('contenido'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('clientes-component')->html();
} elseif ($_instance->childHasBeenRendered('LGJuiTZ')) {
    $componentId = $_instance->getRenderedChildComponentId('LGJuiTZ');
    $componentTag = $_instance->getRenderedChildComponentTagName('LGJuiTZ');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('LGJuiTZ');
} else {
    $response = \Livewire\Livewire::mount('clientes-component');
    $html = $response->html();
    $_instance->logRenderedChild('LGJuiTZ', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\armandomariaga\resources\views/admin/clientes/index.blade.php ENDPATH**/ ?>