

<?php $__env->startSection('contenido'); ?>

<?php
if (! isset($_instance)) {
    $html = \Livewire\Livewire::mount('blog-component')->html();
} elseif ($_instance->childHasBeenRendered('wPCv1i3')) {
    $componentId = $_instance->getRenderedChildComponentId('wPCv1i3');
    $componentTag = $_instance->getRenderedChildComponentTagName('wPCv1i3');
    $html = \Livewire\Livewire::dummyMount($componentId, $componentTag);
    $_instance->preserveRenderedChild('wPCv1i3');
} else {
    $response = \Livewire\Livewire::mount('blog-component');
    $html = $response->html();
    $_instance->logRenderedChild('wPCv1i3', $response->id(), \Livewire\Livewire::getRootElementTagName($html));
}
echo $html;
?>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\laragon\www\web-admin\resources\views/admin/blog/index.blade.php ENDPATH**/ ?>