<?php if(session()->has('register_success')): ?>
      <script  type="text/javascript">
            toastr.success('cliente agregado con exito.', 'Bien hecho!!');
      </script>
<?php endif; ?>

<?php if(session()->has('update-success')): ?>
      <script  type="text/javascript">
            toastr.success('cliente actualizado con exito.', 'Bien hecho!!');
      </script>
<?php endif; ?>

<?php if(session()->has('delete-success')): ?>
      <script  type="text/javascript">
            toastr.error('cliente eliminado con exito.', 'Bien hecho!!');
      </script>
<?php endif; ?><?php /**PATH C:\laragon\www\armandomariaga\resources\views/livewire/clientes/alerts.blade.php ENDPATH**/ ?>