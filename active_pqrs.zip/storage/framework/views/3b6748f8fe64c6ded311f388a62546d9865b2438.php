
<div x-data="{open: <?php if ((object) ('open') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('open'->value()); ?>')<?php echo e('open'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('open'); ?>') <?php endif; ?>, form_create: <?php if ((object) ('form_create') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('form_create'->value()); ?>')<?php echo e('form_create'->hasModifier('defer') ? '.defer' : ''); ?> <?php else : ?> window.Livewire.find('<?php echo e($_instance->id); ?>').entangle('<?php echo e('form_create'); ?>') <?php endif; ?>}" x-init="open = false" class="col-md-12 col-12 mb-2" >

    <div x-show="!open" align="right" class="mb-2">
        <button @click="open = !open" style="margin-right:20px;" type="button" class="btn btn-success round btn-glow px-2">
              Agregar
        </button>
    </div>

    <div x-show="open" align="right" class="mb-2">
        <button wire:click="limpiarDatos" @click="open = !open, form_create = true" style="margin-right:20px;" type="button" class="btn btn-danger round btn-glow px-2">
              Cancelar
        </button>
    </div>

    <div x-show="open">
      <div class="modal-content">

        <div x-show="form_create" style="background:#7DE373 ;" class="modal-header">
          <label class="modal-title text-text-bold-600 text-white">Nueva entrada al BLOG</label>
        </div> 
        <div x-show="!form_create" style="background:#EA5B25 ;" class="modal-header">
          <label class="modal-title text-text-bold-600 text-white">Editar entrada al BLOG</label>
        </div>  

        <form  action="#">
          <div class="modal-body">
            <label>Título: </label>
            <div class="form-group">
              <input type="text" wire:model="titulo" placeholder="Escribra su titulo" class="form-control">
              <?php $__errorArgs = ['titulo'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <label>Contenido: </label>
            <div class="form-group">
              <textarea type="text" wire:model="contenido" placeholder="Escriba su contenido" class="form-control" cols="30" rows="10"></textarea>
              <?php $__errorArgs = ['contenido'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>
            <label>Imagen: </label> <br>
            <span>Formatos admitidos JPEG, JPG, PNG, peso max 2mb</span>
            <div class="form-group">
              <input id="archivo" type="file" wire:model="img" placeholder="Seleccione una imágen" class="form-control">
              <?php $__errorArgs = ['img'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> <span style="color:red;"><?php echo e($message); ?></span> <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
            </div>

            <?php if($img): ?>
              <img style="max-width:150px;" src="<?php echo e($img->temporaryUrl()); ?>" alt="img">
            <?php endif; ?>
          </div>

          <div class="modal-footer">
            <button @click="open = false" type="button" id="form-create-closed" class="btn btn-danger" data-dismiss="modal">Cerrar</button>
            <buttom x-show="form_create" wire:click="store" type="reset" class="btn btn-success">Guardar</buttom>
            <buttom x-show="!form_create" wire:click="update"  type="reset" class="btn btn-success">Actualizar</buttom>
          </div>

        </form>
      </div> 
    </div>
</div>
<?php /**PATH C:\laragon\www\web-admin\resources\views/livewire/blog/forms_blog.blade.php ENDPATH**/ ?>